# Instructions for running docker use the following commands individually

sudo docker build -t mydocker:v1 .  

sudo docker run -it -p 4000:3000 mydocker:v1 

now you can visit the following
http://127.0.0.1:4000/alien_abduction/foo
