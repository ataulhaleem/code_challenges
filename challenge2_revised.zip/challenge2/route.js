var express = require('express'),
    app = express();

       
app.get('/foo', function(req, res) {
    res.json({response: "Hello"});
});

app.get('/bar', function(req, res) {
    res.json({response: "World"});
});

exports.app = app;
