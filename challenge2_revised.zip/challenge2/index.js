const express = require('express');
const app = express();
const routing = require('./route.js').app;


// setting up the port number 
function validPort(num) {
    const regexExp = /^((6553[0-5])|(655[0-2][0-9])|(65[0-4][0-9]{2})|(6[0-4][0-9]{3})|([1-5][0-9]{4})|([0-5]{0,5})|([0-9]{1,4}))$/gi;
    return regexExp.test(num);
}

if( !/^\d+$/.test(process.env.PORT)){
    console.log('port number cannot be empty string or have letters in it, setting to 3000');
    var port = 3000;

}else if(!validPort(process.env.PORT)){
    console.log('port number is invalid, setting to 3000');
    var port = 3000;
}else{
    var port = (process.env.PORT)?process.env.PORT:'3000';
}

// setting up the base url
const base_url = (process.env.BASE_URL)?process.env.BASE_URL:'/alien_abduction';


app.use(base_url, routing);

app.listen(port, () => {
    console.log(`Listening for ${base_url} on port ${port}....`);
});



