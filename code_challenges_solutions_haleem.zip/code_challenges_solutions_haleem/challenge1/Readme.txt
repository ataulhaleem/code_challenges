# to see what each unit test is doing
python3 -m unittest -v
