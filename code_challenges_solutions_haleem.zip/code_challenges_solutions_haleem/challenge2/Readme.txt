# Instructions for running docker

chmod 755 RunDocker.bash
sudo ./RunDocker.bash


OR 

use the following commands individually

sudo docker build -t mydocker:v1 .  
sudo docker run mydocker:v1

If running doesnot  work, alternatively try other free ports e.g
sudo docker run -p 4000:3000 mydocker:v1


now you can visit the following
http://127.0.0.1:port_number/alien_abduction/foo

