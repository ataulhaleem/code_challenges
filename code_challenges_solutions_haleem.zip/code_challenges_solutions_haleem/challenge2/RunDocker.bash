# If the following doesnot work please go to Readme file
docker build -t mydocker:v1 . 
docker run mydocker:v1
