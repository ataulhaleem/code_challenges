$.get('/genotype', function(data){
    // display image
    $('#header').html(data);
});