const express = require('express');
const app = express();
const routing = require('./route.js').app;


if(process.env.BASE_URL != "/alien_abduction"){
    console.error("BASE_URL should be set to '/alien_abduction'");
    process.exit(-1);
}

if(process.env.PORT != "3000"){
    console.error("PORT is not set to '3000'");
    process.exit(-1);
}

app.use(process.env.BASE_URL, routing);

app.listen(process.env.PORT, () => {
    console.log("Server is running ....")
});




